﻿using Statistics;
class Program
{
    public static void Main()
    {
        Console.WriteLine(Statistics.Statistics.DescriptiveStatistics());
        Console.ReadKey();
    }
}
